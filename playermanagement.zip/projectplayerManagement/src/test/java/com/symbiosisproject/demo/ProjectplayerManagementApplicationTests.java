package com.symbiosisproject.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectplayerManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
