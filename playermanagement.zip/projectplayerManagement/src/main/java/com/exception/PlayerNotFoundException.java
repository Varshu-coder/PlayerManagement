package com.exception;

public class PlayerNotFoundException extends Exception {
	public PlayerNotFoundException(String msg)
	{
		super(msg);
	}

}
